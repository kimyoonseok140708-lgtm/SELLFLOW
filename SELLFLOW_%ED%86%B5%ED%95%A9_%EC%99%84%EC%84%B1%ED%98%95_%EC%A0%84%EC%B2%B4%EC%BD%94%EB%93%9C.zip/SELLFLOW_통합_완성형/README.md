# SELLFLOW — 통합 판매·재고·손익 관리

Flask + SQLAlchemy 기반의 다크 모드 판매 관리 웹앱입니다. 기본 통화는 KRW이며, 한 사업장에 여러 직원이 함께 사용하는 구조를 지원합니다.

## 포함 기능
- 최초 사업장/관리자 생성, 로그인, 관리자 초대 링크 및 역할(owner/admin/staff/viewer)
- 사업장별 데이터 격리
- 대시보드: 월 매출·순이익·재고·상품 수, 최근 판매, 6개월 추이, 매출 목표 진행률
- 상품 등록, 모델별 수량 또는 개별 실물 단위 추적, 입고
- 판매 등록, FIFO 방식 원가 계산, 판매 상태 변경 및 취소/반품 재고 복구
- 재고 목록, 비용, 거래처, 월별 손익 보고서, 월별 목표
- 직원 관리, 활동 로그, CSV 내보내기(엑셀에서 열기 가능)
- 비밀번호 해시, 로그인 보호, 역할 기반 서버 권한 검사, 파일 업로드 용량 제한 설정

## Windows + VS Code 실행 (Docker Desktop 사용 권장)
1. ZIP을 새 폴더에 압축 해제하고 VS Code에서 그 폴더를 엽니다.
2. Python 3.11 이상을 설치합니다.
3. Docker Desktop을 설치/실행합니다.
4. 터미널에서 가상환경을 만들고 활성화합니다.
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```
5. 패키지를 설치합니다.
   ```powershell
   pip install -r requirements.txt
   ```
6. 환경 파일을 복사합니다.
   ```powershell
   Copy-Item .env.example .env
   ```
   `.env`의 `SECRET_KEY`를 충분히 길고 임의적인 값으로 바꾸세요.
7. PostgreSQL을 실행합니다.
   ```powershell
   docker compose up -d
   ```
8. 앱을 실행합니다.
   ```powershell
   python app.py
   ```
9. 브라우저에서 http://127.0.0.1:5000 을 엽니다.
10. 최초 접속 시 회원가입 화면에서 사업장과 최고 관리자 계정을 생성합니다.

## 간단 실행(데이터베이스 설치 없이)
`.env`에서 `DATABASE_URL` 줄을 삭제하거나 다음으로 바꾸면 SQLite 로컬 테스트 모드로 실행됩니다.
`DATABASE_URL=sqlite:///sellflow_dev.db`
SQLite는 단일 PC 시험용입니다. 여러 직원이 동시에 접속하는 운영 환경에는 PostgreSQL을 사용하세요.

## 직원 초대
관리자 계정으로 로그인 → 직원 관리 → 이메일과 권한 선택 → 초대 링크 생성. 링크는 7일간 유효합니다. 생성된 링크를 초대할 직원에게 안전한 방법으로 전달하세요.

## 재고 방식
- 모델별: 상품 모델에 재고 수량을 등록하고 판매할 수 있습니다. 원가는 입고 단위별 FIFO로 계산합니다.
- 개별 단위: 실물 상품마다 시리얼/상태/구성품/배터리/매입가를 별도 기록합니다.
- 모델별과 개별 단위는 상품을 등록할 때 선택합니다.

## 운영 전 필수 점검
이 프로젝트는 실제 데이터 처리의 출발점이며, 무점검 상태로 인터넷에 공개할 수 있는 완성 보안 제품은 아닙니다.
- 배포 시 HTTPS, 강력한 SECRET_KEY, 운영용 DB 비밀번호, 방화벽 및 접근 제한을 적용하세요.
- 기본 최초 관리자 생성은 빈 DB에서 한 번만 가능합니다.
- 정산은 거래완료 판매와 등록된 비용을 기준으로 계산합니다. 취소/반품은 판매 상태에 따라 재고를 복구하며, 실제 환불·부분반품·회계 증빙 규칙은 사업장 정책에 맞춰 추가 검증해야 합니다.
- 이미지 업로드 UI, 세부 상품 수정/삭제, 정산 잠금, XLSX 직접 생성, 자동 백업·복구, 고급 검색 및 상세 감사 추적은 다음 개발 범위입니다. CSV는 Excel에서 열 수 있습니다.
- 실제 사업 데이터 입력 전에 테스트 DB로 판매/취소/반품/재고 흐름을 충분히 검증하고 백업을 준비하세요.

## 프로젝트 구조
```text
SELLFLOW/
├─ app.py
├─ requirements.txt
├─ .env.example
├─ docker-compose.yml
├─ README.md
├─ templates/
│  ├─ base.html
│  ├─ login.html
│  ├─ register.html
│  ├─ invite.html
│  ├─ dashboard.html
│  ├─ products.html
│  ├─ sales.html
│  ├─ inventory.html
│  ├─ expenses.html
│  ├─ partners.html
│  ├─ goals.html
│  ├─ reports.html
│  ├─ team.html
│  ├─ activity.html
│  └─ settings.html
└─ static/
   ├─ style.css
   └─ app.js
```
