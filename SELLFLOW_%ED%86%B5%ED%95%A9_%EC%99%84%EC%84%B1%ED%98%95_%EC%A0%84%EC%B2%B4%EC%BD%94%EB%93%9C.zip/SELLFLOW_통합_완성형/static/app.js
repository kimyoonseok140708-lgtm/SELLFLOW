document.addEventListener("DOMContentLoaded",()=>{
  const c=document.getElementById("salesChart");
  if(c && window.sellflowChart && window.Chart){
    new Chart(c,{type:"line",data:{labels:window.sellflowChart.labels,datasets:[
      {label:"매출",data:window.sellflowChart.revenue,tension:.35,borderWidth:2},
      {label:"순이익",data:window.sellflowChart.profit,tension:.35,borderWidth:2}
    ]},options:{responsive:true,plugins:{legend:{labels:{color:"#aab2c5"}}},
      scales:{x:{ticks:{color:"#8d96aa"},grid:{color:"#242a38"}},y:{ticks:{color:"#8d96aa",callback:v=>"₩"+Number(v).toLocaleString("ko-KR")},grid:{color:"#242a38"}}}}});
  }
});
