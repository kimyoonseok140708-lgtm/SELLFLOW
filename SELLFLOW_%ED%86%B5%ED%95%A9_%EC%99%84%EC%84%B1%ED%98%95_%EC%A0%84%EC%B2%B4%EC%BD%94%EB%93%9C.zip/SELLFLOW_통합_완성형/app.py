import os, io, csv, secrets
from datetime import datetime, date, timedelta
from functools import wraps
from decimal import Decimal, InvalidOperation
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-before-deployment")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///sellflow_dev.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = os.path.join(app.root_path, "static", "uploads")
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "로그인이 필요합니다."

# ---------- Data models ----------
class Workspace(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    currency = db.Column(db.String(3), default="KRW", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False)
    username = db.Column(db.String(60), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="staff", nullable=False) # owner/admin/staff/viewer
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def set_password(self, p): self.password_hash = generate_password_hash(p)
    def check_password(self, p): return check_password_hash(self.password_hash, p)

class Invite(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    role = db.Column(db.String(20), default="staff")
    token = db.Column(db.String(80), unique=True, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)
    created_by = db.Column(db.Integer, db.ForeignKey("user.id"))

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    code = db.Column(db.String(80))
    category = db.Column(db.String(80), default="전자기기")
    tracking_type = db.Column(db.String(20), default="model") # model / unit
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class StockUnit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False, index=True)
    serial = db.Column(db.String(120))
    condition = db.Column(db.String(60), default="중고 - 양호")
    accessories = db.Column(db.String(255))
    battery = db.Column(db.String(80))
    purchase_cost = db.Column(db.Integer, default=0)
    sale_price = db.Column(db.Integer, default=0)
    quantity = db.Column(db.Integer, default=1)
    status = db.Column(db.String(20), default="available") # available/sold
    purchase_date = db.Column(db.Date)
    supplier_id = db.Column(db.Integer, db.ForeignKey("partner.id"))
    notes = db.Column(db.Text)
    image = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Partner(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    kind = db.Column(db.String(20), default="매입처")
    phone = db.Column(db.String(40))
    email = db.Column(db.String(160))
    memo = db.Column(db.Text)

class Sale(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    stock_unit_id = db.Column(db.Integer, db.ForeignKey("stock_unit.id"))
    quantity = db.Column(db.Integer, default=1)
    sale_price = db.Column(db.Integer, nullable=False)
    cost = db.Column(db.Integer, default=0)
    shipping = db.Column(db.Integer, default=0)
    fee = db.Column(db.Integer, default=0)
    channel = db.Column(db.String(60), default="직거래")
    buyer = db.Column(db.String(120))
    status = db.Column(db.String(30), default="완료")
    sold_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    product = db.relationship("Product")
    stock_unit = db.relationship("StockUnit")
    seller = db.relationship("User")

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False, index=True)
    category = db.Column(db.String(60), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    memo = db.Column(db.String(255))
    spent_at = db.Column(db.Date, default=date.today)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))

class Goal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False, index=True)
    month = db.Column(db.String(7), nullable=False)
    sales_target = db.Column(db.Integer, default=0)
    profit_target = db.Column(db.Integer, default=0)

class Activity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspace.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    action = db.Column(db.String(120), nullable=False)
    detail = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    actor = db.relationship("User")

@login_manager.user_loader
def load_user(uid): return db.session.get(User, int(uid))

# ---------- Helpers ----------
def wid(): return current_user.workspace_id
def money(v): return f"₩{int(v or 0):,}"
app.jinja_env.filters["money"] = money

def log(action, detail=""):
    db.session.add(Activity(workspace_id=wid(), user_id=current_user.id, action=action, detail=detail))

def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        @login_required
        def wrapped(*a, **kw):
            if current_user.role not in allowed:
                flash("이 작업을 수행할 권한이 없습니다.", "error")
                return redirect(url_for("dashboard"))
            return fn(*a, **kw)
        return wrapped
    return deco

def scoped(model, ident):
    obj = db.session.get(model, ident)
    if not obj or obj.workspace_id != wid(): abort(404)
    return obj

def num(name, default=0):
    try: return max(0, int(request.form.get(name, default) or default))
    except (ValueError, TypeError): return default

def month_start():
    return date.today().replace(day=1)

def sales_query():
    return Sale.query.filter_by(workspace_id=wid(), status="완료")

def profit_for(s):
    return s.sale_price * s.quantity - s.cost * s.quantity - s.shipping - s.fee

@app.route("/")
def index(): return redirect(url_for("dashboard" if current_user.is_authenticated else "login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if User.query.first():
        flash("첫 관리자 계정은 최초 설치 때만 생성할 수 있습니다. 관리자의 초대를 이용하세요.", "error")
        return redirect(url_for("login"))
    if request.method == "POST":
        name=request.form.get("workspace","내 사업장").strip()
        username=request.form.get("username","").strip()
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        if len(password)<8 or not username or not email:
            flash("이름과 이메일을 입력하고 비밀번호는 8자 이상 설정하세요.", "error")
        else:
            w=Workspace(name=name); db.session.add(w); db.session.flush()
            u=User(workspace_id=w.id, username=username, email=email, role="owner"); u.set_password(password)
            db.session.add(u)
            try:
                db.session.commit(); login_user(u); return redirect(url_for("dashboard"))
            except IntegrityError:
                db.session.rollback(); flash("이미 사용 중인 이메일입니다.", "error")
    return render_template("register.html", setup=True)

@app.route("/login", methods=["GET","POST"])
def login():
    if current_user.is_authenticated: return redirect(url_for("dashboard"))
    if request.method=="POST":
        u=User.query.filter_by(email=request.form.get("email","").lower().strip()).first()
        if u and u.active and u.check_password(request.form.get("password","")):
            login_user(u); return redirect(url_for("dashboard"))
        flash("이메일 또는 비밀번호를 확인하세요.", "error")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout(): logout_user(); return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    start=month_start()
    q=sales_query()
    month_sales=q.filter(Sale.sold_at>=datetime.combine(start, datetime.min.time())).all()
    revenue=sum(s.sale_price*s.quantity for s in month_sales)
    cogs=sum(s.cost*s.quantity for s in month_sales)
    sale_cost=sum(s.shipping+s.fee for s in month_sales)
    expenses=Expense.query.filter_by(workspace_id=wid()).filter(Expense.spent_at>=start).all()
    expense_total=sum(e.amount for e in expenses)
    profit=revenue-cogs-sale_cost-expense_total
    products=Product.query.filter_by(workspace_id=wid()).count()
    stock=StockUnit.query.filter_by(workspace_id=wid(),status="available").all()
    stock_count=sum(u.quantity for u in stock)
    goal=Goal.query.filter_by(workspace_id=wid(),month=date.today().strftime("%Y-%m")).first()
    recent=Sale.query.filter_by(workspace_id=wid()).order_by(Sale.sold_at.desc()).limit(8).all()
    # Last six months for chart
    labels=[]; revs=[]; profits=[]
    for offset in range(5,-1,-1):
        d=(date.today().replace(day=1)-timedelta(days=1)).replace(day=1) if offset==0 else date.today().replace(day=1)
        # stable month arithmetic
        y=date.today().year; m=date.today().month-offset
        while m<=0: y-=1; m+=12
        label=f"{y}-{m:02d}"; labels.append(label)
        rows=q.filter(func.strftime("%Y-%m", Sale.sold_at)==label).all() if "sqlite" in app.config["SQLALCHEMY_DATABASE_URI"] else q.filter(func.to_char(Sale.sold_at,"YYYY-MM")==label).all()
        rv=sum(s.sale_price*s.quantity for s in rows); revs.append(rv)
        ex=Expense.query.filter_by(workspace_id=wid()).filter(func.strftime("%Y-%m",Expense.spent_at)==label).all() if "sqlite" in app.config["SQLALCHEMY_DATABASE_URI"] else Expense.query.filter_by(workspace_id=wid()).filter(func.to_char(Expense.spent_at,"YYYY-MM")==label).all()
        profits.append(rv-sum(s.cost*s.quantity+s.shipping+s.fee for s in rows)-sum(e.amount for e in ex))
    return render_template("dashboard.html", revenue=revenue, profit=profit, stock_count=stock_count,
        products=products, recent=recent, labels=labels, revs=revs, profits=profits, goal=goal,
        goal_rate=min(100, int(revenue/goal.sales_target*100)) if goal and goal.sales_target else 0)

@app.route("/products", methods=["GET","POST"])
@login_required
def products():
    if request.method=="POST":
        if current_user.role == "viewer": abort(403)
        p=Product(workspace_id=wid(), name=request.form["name"].strip(), code=request.form.get("code"),
                  category=request.form.get("category","전자기기"), tracking_type=request.form.get("tracking_type","model"),
                  description=request.form.get("description"))
        db.session.add(p); db.session.flush()
        qty=num("quantity",1); qty=max(1,qty)
        u=StockUnit(workspace_id=wid(), product_id=p.id, serial=request.form.get("serial"),
            condition=request.form.get("condition","중고 - 양호"), accessories=request.form.get("accessories"),
            battery=request.form.get("battery"), purchase_cost=num("purchase_cost"), sale_price=num("sale_price"),
            quantity=1 if p.tracking_type=="unit" else qty, status="available",
            purchase_date=date.today(), notes=request.form.get("notes"))
        db.session.add(u); log("상품 등록",p.name); db.session.commit()
        flash("상품과 초기 재고를 등록했습니다."); return redirect(url_for("products"))
    q=request.args.get("q","").strip()
    query=Product.query.filter_by(workspace_id=wid())
    if q: query=query.filter(or_(Product.name.ilike(f"%{q}%"),Product.code.ilike(f"%{q}%")))
    items=query.order_by(Product.created_at.desc()).all()
    stock_data=[]
    for p in items:
        units=StockUnit.query.filter_by(workspace_id=wid(),product_id=p.id,status="available").all()
        stock_data.append((p, sum(x.quantity for x in units), units))
    return render_template("products.html", items=stock_data, partners=Partner.query.filter_by(workspace_id=wid()).all())

@app.route("/products/<int:pid>/stock", methods=["POST"])
@roles("owner","admin","staff")
def add_stock(pid):
    p=scoped(Product,pid)
    u=StockUnit(workspace_id=wid(),product_id=p.id,serial=request.form.get("serial"),
        condition=request.form.get("condition","중고 - 양호"),accessories=request.form.get("accessories"),
        battery=request.form.get("battery"),purchase_cost=num("purchase_cost"),sale_price=num("sale_price"),
        quantity=1 if p.tracking_type=="unit" else max(1,num("quantity",1)),status="available",
        purchase_date=date.today(),notes=request.form.get("notes"))
    db.session.add(u); log("재고 입고",p.name); db.session.commit()
    flash("재고를 입고했습니다."); return redirect(url_for("products"))

@app.route("/sales", methods=["GET","POST"])
@login_required
def sales():
    if request.method=="POST":
        if current_user.role == "viewer": abort(403)
        p=scoped(Product,int(request.form["product_id"]))
        unit_id=request.form.get("stock_unit_id")
        unit=scoped(StockUnit,int(unit_id)) if unit_id else None
        qty=max(1,num("quantity",1))
        if unit:
            if unit.status!="available" or unit.quantity<qty:
                flash("선택한 재고의 수량이 부족합니다.","error"); return redirect(url_for("sales"))
            cost=unit.purchase_cost
            if p.tracking_type=="unit": unit.status="sold"
            else: unit.quantity-=qty
        else:
            available=StockUnit.query.filter_by(workspace_id=wid(),product_id=p.id,status="available").all()
            if sum(x.quantity for x in available)<qty:
                flash("재고가 부족합니다.","error"); return redirect(url_for("sales"))
            # FIFO cost allocation
            remaining=qty; cost_total=0
            for x in sorted(available,key=lambda z:z.purchase_date or date.min):
                take=min(remaining,x.quantity); cost_total+=take*x.purchase_cost; x.quantity-=take; remaining-=take
                if remaining==0: break
            cost=round(cost_total/qty)
        sale=Sale(workspace_id=wid(),product_id=p.id,stock_unit_id=unit.id if unit else None,quantity=qty,
            sale_price=num("sale_price"),cost=cost,shipping=num("shipping"),fee=num("fee"),
            channel=request.form.get("channel","직거래"),buyer=request.form.get("buyer"),
            status=request.form.get("status","완료"),user_id=current_user.id)
        db.session.add(sale); log("판매 등록",f"{p.name} × {qty}"); db.session.commit()
        flash("판매를 등록했습니다."); return redirect(url_for("sales"))
    products=Product.query.filter_by(workspace_id=wid()).all()
    units=StockUnit.query.filter_by(workspace_id=wid(),status="available").all()
    rows=Sale.query.filter_by(workspace_id=wid()).order_by(Sale.sold_at.desc()).limit(100).all()
    return render_template("sales.html", products=products, units=units, rows=rows)

@app.route("/sales/<int:sid>/status", methods=["POST"])
@roles("owner","admin","staff")
def sale_status(sid):
    s=scoped(Sale,sid); new=request.form.get("status")
    if s.status in ("취소", "반품") and new != s.status:
        flash("취소/반품 처리된 거래는 상태를 다시 변경할 수 없습니다. 새 판매로 등록하세요.", "error")
        return redirect(url_for("sales"))
    if s.status == "완료" and new not in ("완료", "취소", "반품"):
        flash("완료된 판매는 취소 또는 반품으로만 변경할 수 있습니다.", "error")
        return redirect(url_for("sales"))
    if s.status=="완료" and new in ("취소","반품"):
        # Restore stock only once; terminal statuses prevent duplicate restoration.
        if s.stock_unit:
            if s.product.tracking_type=="unit": s.stock_unit.status="available"
            else: s.stock_unit.quantity+=s.quantity
        else:
            db.session.add(StockUnit(workspace_id=wid(),product_id=s.product_id,purchase_cost=s.cost,
                sale_price=s.sale_price,quantity=s.quantity,status="available",condition="반품 재입고"))
    s.status=new; log("판매 상태 변경",f"판매 #{s.id}: {new}"); db.session.commit()
    flash("판매 상태를 변경했습니다."); return redirect(url_for("sales"))

@app.route("/inventory")
@login_required
def inventory():
    units=StockUnit.query.filter_by(workspace_id=wid()).order_by(StockUnit.created_at.desc()).all()
    return render_template("inventory.html", units=units)

@app.route("/expenses", methods=["GET","POST"])
@login_required
def expenses():
    if request.method=="POST":
        if current_user.role == "viewer": abort(403)
        e=Expense(workspace_id=wid(),category=request.form.get("category"),amount=num("amount"),
                  memo=request.form.get("memo"),spent_at=date.fromisoformat(request.form.get("spent_at") or date.today().isoformat()),user_id=current_user.id)
        db.session.add(e); log("비용 등록",e.category); db.session.commit()
        flash("비용을 등록했습니다."); return redirect(url_for("expenses"))
    rows=Expense.query.filter_by(workspace_id=wid()).order_by(Expense.spent_at.desc()).limit(200).all()
    return render_template("expenses.html",rows=rows)

@app.route("/partners", methods=["GET","POST"])
@login_required
def partners():
    if request.method=="POST":
        if current_user.role == "viewer": abort(403)
        p=Partner(workspace_id=wid(),name=request.form.get("name"),kind=request.form.get("kind"),
                  phone=request.form.get("phone"),email=request.form.get("email"),memo=request.form.get("memo"))
        db.session.add(p); log("거래처 등록",p.name); db.session.commit()
        flash("거래처를 등록했습니다."); return redirect(url_for("partners"))
    rows=Partner.query.filter_by(workspace_id=wid()).order_by(Partner.name).all()
    return render_template("partners.html",rows=rows)

@app.route("/goals", methods=["GET","POST"])
@roles("owner","admin")
def goals():
    month=date.today().strftime("%Y-%m")
    if request.method=="POST":
        month=request.form.get("month")
        g=Goal.query.filter_by(workspace_id=wid(),month=month).first()
        if not g: g=Goal(workspace_id=wid(),month=month); db.session.add(g)
        g.sales_target=num("sales_target"); g.profit_target=num("profit_target")
        log("목표 설정",month); db.session.commit(); flash("목표를 저장했습니다.")
    rows=Goal.query.filter_by(workspace_id=wid()).order_by(Goal.month.desc()).all()
    return render_template("goals.html",rows=rows,month=month)

@app.route("/reports")
@login_required
def reports():
    month=request.args.get("month",date.today().strftime("%Y-%m"))
    sales_rows=sales_query().filter(func.strftime("%Y-%m",Sale.sold_at)==month).all() if "sqlite" in app.config["SQLALCHEMY_DATABASE_URI"] else sales_query().filter(func.to_char(Sale.sold_at,"YYYY-MM")==month).all()
    exps=Expense.query.filter_by(workspace_id=wid()).filter(func.strftime("%Y-%m",Expense.spent_at)==month).all() if "sqlite" in app.config["SQLALCHEMY_DATABASE_URI"] else Expense.query.filter_by(workspace_id=wid()).filter(func.to_char(Expense.spent_at,"YYYY-MM")==month).all()
    revenue=sum(s.sale_price*s.quantity for s in sales_rows); cogs=sum(s.cost*s.quantity for s in sales_rows)
    fees=sum(s.fee+s.shipping for s in sales_rows); other=sum(e.amount for e in exps)
    return render_template("reports.html",month=month,rows=sales_rows,expenses=exps,revenue=revenue,cogs=cogs,fees=fees,other=other,profit=revenue-cogs-fees-other)

@app.route("/team", methods=["GET","POST"])
@roles("owner","admin")
def team():
    if request.method=="POST":
        email=request.form.get("email","").strip().lower()
        role=request.form.get("role","staff")
        if role not in ("admin","staff","viewer"): role="staff"
        token=secrets.token_urlsafe(28)
        inv=Invite(workspace_id=wid(),email=email,role=role,token=token,expires_at=datetime.utcnow()+timedelta(days=7),created_by=current_user.id)
        db.session.add(inv); log("직원 초대 생성",email); db.session.commit()
        flash(f"초대 링크(7일 유효): {url_for('accept_invite',token=token,_external=True)}")
    users=User.query.filter_by(workspace_id=wid()).all()
    invites=Invite.query.filter_by(workspace_id=wid(),used=False).all()
    return render_template("team.html",users=users,invites=invites)

@app.route("/invite/<token>", methods=["GET","POST"])
def accept_invite(token):
    inv=Invite.query.filter_by(token=token,used=False).first_or_404()
    if inv.expires_at<datetime.utcnow(): abort(410)
    if request.method=="POST":
        if User.query.filter_by(email=inv.email).first(): flash("이미 등록된 이메일입니다.","error")
        else:
            u=User(workspace_id=inv.workspace_id,username=request.form.get("username"),email=inv.email,role=inv.role)
            u.set_password(request.form.get("password",""))
            if len(request.form.get("password",""))<8: flash("비밀번호는 8자 이상이어야 합니다.","error")
            else:
                db.session.add(u); inv.used=True; db.session.commit(); login_user(u); return redirect(url_for("dashboard"))
    return render_template("invite.html",inv=inv)

@app.route("/activity")
@roles("owner","admin")
def activity():
    rows=Activity.query.filter_by(workspace_id=wid()).order_by(Activity.created_at.desc()).limit(250).all()
    return render_template("activity.html",rows=rows)

@app.route("/export/<kind>")
@login_required
def export(kind):
    output=io.StringIO(); w=csv.writer(output)
    if kind=="sales":
        w.writerow(["판매일","상품","수량","판매가","원가","배송비","수수료","판매경로","상태","담당자"])
        for s in Sale.query.filter_by(workspace_id=wid()).all():
            w.writerow([s.sold_at.strftime("%Y-%m-%d"),s.product.name,s.quantity,s.sale_price,s.cost,s.shipping,s.fee,s.channel,s.status,s.seller.username])
    elif kind=="inventory":
        w.writerow(["상품","시리얼","상태","수량","매입가","판매가","재고상태"])
        for u in StockUnit.query.filter_by(workspace_id=wid()).all():
            w.writerow([u.product.name,u.serial,u.condition,u.quantity,u.purchase_cost,u.sale_price,u.status])
    elif kind=="expenses":
        w.writerow(["일자","분류","금액","메모"])
        for e in Expense.query.filter_by(workspace_id=wid()).all(): w.writerow([e.spent_at,e.category,e.amount,e.memo])
    else: abort(404)
    data=io.BytesIO(("\ufeff"+output.getvalue()).encode("utf-8-sig"))
    return send_file(data,mimetype="text/csv; charset=utf-8",as_attachment=True,download_name=f"sellflow_{kind}_{date.today()}.csv")

@app.route("/settings")
@login_required
def settings():
    return render_template("settings.html",workspace=db.session.get(Workspace,wid()))

@app.errorhandler(413)
def too_large(e): return "업로드 용량은 8MB 이하로 제한됩니다.",413

with app.app_context():
    db.create_all()

if __name__=="__main__":
    app.run(host="127.0.0.1",port=int(os.getenv("PORT",5000)),debug=os.getenv("FLASK_DEBUG","0")=="1")
